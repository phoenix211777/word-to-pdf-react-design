export type Props = {
  title: boolean;
};
